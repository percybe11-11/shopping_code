export function priceCount(priceCents){
    return (priceCents/100).toFixed(2);
}